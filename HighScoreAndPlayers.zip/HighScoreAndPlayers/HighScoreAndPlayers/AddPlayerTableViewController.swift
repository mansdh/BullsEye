//
//  AddPlayerTableViewController.swift
//  HighScoreAndPlayers
//
//  Created by Manuel on 4/16/16.
//  Copyright © 2016 Itesm All rights reserved.
//

import UIKit
protocol AddItemDelegate: class {
    func addItemDelegateCancel(controller: AddPlayerTableViewController)
    func addItemDelegateDone(controller: AddPlayerTableViewController,finishingAddingItem item: Player)
}

class AddPlayerTableViewController: UITableViewController {
    @IBOutlet weak var TextFiled: UITextField!
    weak var delegate: AddItemDelegate!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }



    // MARK: - Table view data source





    @IBAction func Cancel(sender: AnyObject) {
        delegate?.addItemDelegateCancel(self)
    }
    @IBAction func Done(sender: AnyObject) {
        let play = Player()
        play.name = TextFiled.text!
        play.score = 0
        delegate?.addItemDelegateDone(self, finishingAddingItem: play)
    }
    //primero
    override func tableView(tableView: UITableView, willSelectRowAtIndexPath indexPath: NSIndexPath) -> NSIndexPath? {
        return nil
    }
    //despues
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }
}