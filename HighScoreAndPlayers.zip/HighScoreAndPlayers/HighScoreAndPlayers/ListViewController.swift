//
//  ViewController.swift
//  HighScoreAndPlayers
//
//  Created by Manuel on 4/16/16.
//  Copyright © 2016 Itesm All rights reserved.
//

import UIKit

class ListViewController: UITableViewController, AddItemDelegate ,PlayerDelegate{
    

    
    var items : [Player] = []
    var indexpath : NSIndexPath?
    required init?(coder aDecoder: NSCoder) {
       
        
        //create array items
        items = [Player]()
        
        
       // items.append(item)
        super.init(coder: aDecoder)
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("ListItem", forIndexPath: indexPath)
        updateCellWithItem(cell, item: items[indexPath.row])
        return cell
    }
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        indexpath = indexPath
        let storyboard = UIStoryboard(name: "Main", bundle: NSBundle.mainBundle())
        let destination = storyboard.instantiateViewControllerWithIdentifier("viewController") as! ViewController
        destination.playerActive = items[indexPath.row]
        destination.delegateplayer = self
        destination.indexpathdelegate = indexpath
        // navigationController?.pushViewController(destination, animated: true)
        presentViewController(destination, animated: true, completion: nil)
    }

    func updateCellWithItem(cell: UITableViewCell, item: Player){
        let label = cell.viewWithTag(100) as! UILabel
        label.text = item.name
        let label2 = cell.viewWithTag(200) as! UILabel
        label2.text = String(item.score)
        
        
    }
    func UpdatePlayer(controller: ViewController,player: Player, indexP:NSIndexPath){
        controller.dismissViewControllerAnimated(true, completion: nil)
        
        items[indexP.row].name = player.name
        items[indexP.row].score = player.score
        let cell = tableView.dequeueReusableCellWithIdentifier("ListItem", forIndexPath: indexP)
        updateCellWithItem(cell, item: items[indexP.row])
        self.tableView.reloadData()
        self.navigationController?.popViewControllerAnimated(true)
    }
    

    
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        items.removeAtIndex(indexPath.row)//UpdateModel
        let indexpaths = [indexPath]
        tableView.deleteRowsAtIndexPaths(indexpaths, withRowAnimation: .Fade)
    }
    
     func addItemDelegateCancel(controller: AddPlayerTableViewController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    func addItemDelegateDone(controller: AddPlayerTableViewController, finishingAddingItem itm: Player) {
        dismissViewControllerAnimated(true, completion: nil)
        let newItem = itm
        
        let indexitem = items.count
        items.append(newItem)
        let indexPath = NSIndexPath(forRow: indexitem, inSection: 0)
        tableView.insertRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
    }
    

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "addPlayer"{
            let navigatorController =  segue.destinationViewController as! UINavigationController
            let controller = navigatorController.topViewController as! AddPlayerTableViewController
            controller.delegate = self
        }
          }
    
}

