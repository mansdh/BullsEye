//
//  Player.swift
//  HighScoreAndPlayers
//
//  Created by Manuel on 4/16/16.
//  Copyright © 2016 Itesm All rights reserved.
//

import Foundation
class Player{
    var name = "";
    var score = 0;
    
}