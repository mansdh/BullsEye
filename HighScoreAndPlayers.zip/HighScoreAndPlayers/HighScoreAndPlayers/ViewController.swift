//
//  ViewController.swift
//  GuessGame
//
//  Created by Manuel on 4/16/16.
//  Copyright © 2016 Itesm All rights reserved.
//

import UIKit
protocol PlayerDelegate: class {
   
    func UpdatePlayer(controller: ViewController,player: Player, indexP:NSIndexPath)
}

class ViewController: UIViewController {
    var playerActive: Player!
    var delegateplayer: PlayerDelegate!
    var indexpathdelegate: NSIndexPath!
    var targetValue :Int=0;
    var round :Int=0;
    var score:Int=0;
    @IBOutlet weak var roundLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    @IBOutlet weak var randomNum: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    //Optionals investgate
    @IBOutlet weak var slider: UISlider!
    @IBAction func HitmePressed(sender: AnyObject) {
        print(slider.value)
        getScore();
        slider.value=50;
        //newRound();
        //setLabels();
        
    }
    
    func generateRandomNumber()->Void{
        targetValue = 1+Int(arc4random_uniform(100));
    }
    func newRound(){
        round+=1;
        generateRandomNumber();
    }
    func getScore(){
        let diference :Int=Int(slider.value)-targetValue;
        var scorep:Int;
        if(diference<0){
            scorep = (100 + diference);
        }else{
            scorep = (100 - diference);
        }
        score+=scorep;
        print(scorep,score);
        rateTry(scorep)
        
        
    }
    func rateTry(let difference:Int){
        var title:String="";
        if (difference==100){
            title="Perfect"
        }else{
            if(difference>80){
                title="good"
            }else{
                if(difference>50){
                    title="nice"
                }else{
                    title="keep trying"                }
            }
        }
        let message = "You scored  \(difference) points";
        let alert = UIAlertController(title:title,message: message,preferredStyle:UIAlertControllerStyle.Alert );
        let action = UIAlertAction(title: "Ok", style: .Default, handler:
            { myvar in
                self.newRound()
                self.setLabels()
        })
        alert.addAction(action)
        presentViewController(alert,animated: true, completion: nil)
        
    }
    
    
    
    @IBAction func sliderMoved(sender: AnyObject) {
    }
    @IBAction func StartOverPress(sender: AnyObject) {
        if ( Int (scoreLabel.text!)! > playerActive.score){
            playerActive.score = Int (scoreLabel.text!)!
            delegateplayer.UpdatePlayer(self, player: playerActive, indexP: indexpathdelegate)
            self.dismissViewControllerAnimated(true, completion: nil)
        }else{
            self.dismissViewControllerAnimated(true, completion: nil)
        }
    }
    func setLabels(){
        randomNum.text = String(targetValue);//o tambien("\targetValue")
        roundLabel.text=String(round);
        scoreLabel.text=String(score);
    }
    //testo is the mane of the variable ouside the function
    func hellowWorldWithString( testo title:String) {
        //title is he name of the varible inside the function
        print(title);
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        round=0;
        score=0;
        slider.value=50;
        newRound();
        setLabels();
        nameLabel.text = playerActive.name
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
}

